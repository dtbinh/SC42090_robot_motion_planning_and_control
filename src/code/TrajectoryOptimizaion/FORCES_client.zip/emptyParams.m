% Initializes empty parameters struct.
%
% This file is part of the FORCES Pro client software for Matlab.
% (c) embotech AG, 2013-18, Zurich, Switzerland. All rights reserved.
%
% This file is part of the FORCES Pro client software for Matlab.
% (c) embotech AG, 2013-2018, Zurich, Switzerland. All rights reserved.
