function server = default_forces_server()
% Enter the default FORCES Pro server URL here.
server = 'https://forces.embotech.com';
